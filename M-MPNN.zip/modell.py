import copy
import math

import numpy as np
import torch.nn.functional as F
import torch.nn as nn
import torch
import torch.autograd
import rdkit
from rdkit import Chem
from rdkit.Chem import AllChem
from rdkit.Chem.Scaffolds import MurckoScaffold
from rdkit.ML.Descriptors import MoleculeDescriptors
from torch_geometric.utils import dense_to_sparse
from torch_scatter import scatter_mean

from utils import featurize_mol2,edge_in
from graph import create_graph
from torch_geometric.nn import NNConv, GCNConv, GATConv
from pubchemfp import GetPubChemFPs
from torch_geometric.nn import MessagePassing
from torch_geometric.utils import add_self_loops,degree

class Mmpnn(nn.Module):
    def __init__(self,args):
        super(Mmpnn, self).__init__()
        self.task_num = args.task_num
        self.muti = Mutilayer()
        self.muti2 = Mutilayer()
        self.m_conv1 = M_conv1(args)
        self.mpnn = Mpnnlayer2()
        self.mpnn2 = Mpnnlayer2()
        self.mu = MultiHeadSelfAttention(36,128,36)
        self.sm = SelfAttention(4,36,36,0.2)
        # self.smc = SmoothDilatedResidualBlock(1,2)
        self.fc1 = nn.Sequential(
            nn.Linear(1489, 512),
            nn.ReLU(),
            nn.Dropout(0.2),
            nn.Linear(512, 300),
            nn.ReLU(),
            # nn.Linear(32,self.task_num),
        )
        self.fc2 = nn.Sequential(
            nn.Linear(108, 100),
            nn.ReLU(),
            # nn.Linear(600, 300),
            # nn.ReLU(),
            # nn.Linear(32,self.task_num),
        )
        self.fc = nn.Sequential(
            nn.Linear(600,300),
            nn.ReLU(),
            nn.Linear(300, self.task_num),
            # nn.ReLU(),
            # nn.Linear(32,self.task_num),
        )
    def forward(self, smiles):
        device = torch.device('cuda:3' if torch.cuda.is_available() else 'cpu')
        fp_maccs = []
        g_outs = []
        for i,smi in enumerate(smiles):
            # mol =AllChem.AddHs(Chem.MolFromSmiles(smi))
            mol = Chem.MolFromSmiles(smi)
            fp = list(AllChem.GetMACCSKeysFingerprint(mol))
            fp1 = list(GetPubChemFPs(mol))
            fp2 = list(AllChem.GetErGFingerprint(mol,fuzzIncrement=0.3,maxPath=21,minPath=1))
            fp = fp + fp1 + fp2
            fp_maccs.append(fp)
            e_fea, b_fea,edge_index, edge_tup2, atom_dict,node_features,node_features1 = featurize_mol2(mol)
            """---------------------------------使用边算edge_tup-----------------------------------"""
            e_fea = torch.tensor(e_fea,dtype=torch.float).to(device)
            b_fea = torch.tensor(b_fea, dtype=torch.float).to(device)
            edge_index = edge_index.to(device)
            """------------------------------------------------------------------------------------"""

            """--------------------------------图1----------------------------------------------"""
            b_fea = torch.unsqueeze(b_fea, dim=0)  # 1*n*28
            muti_o = self.muti(b_fea)
            muti_o = torch.squeeze(muti_o, dim=0)
            e_fea = torch.cat((e_fea,muti_o),dim=1)
            mpnn_o = self.mpnn(e_fea,edge_index,edge_tup2) #点 n*28
            g_out = read_out(mpnn_o, mol, atom_dict)
            # oo = torch.unsqueeze(oo,dim=1)
            # g_out = torch.cat((g_out,oo),dim=1)
            g_outs.append(g_out)
            """------------------------------------------------------------------------------------"""

        g_outs = torch.stack(g_outs)#50*14*36
        out = self.m_conv1(g_outs)
        fp_maccs = torch.tensor(fp_maccs,dtype=torch.float).to(device)
        fp_maccs = self.fc1(fp_maccs)
        full_in = torch.cat((out,fp_maccs),dim=1)
        full_out = self.fc(full_in.view(full_in.size(0),-1))
        return full_out

def read_out(mpnn_out,mol,atom_dict):
    g_out = []
    m_out = mpnn_out.cpu()
    device = torch.device('cuda:3' if torch.cuda.is_available() else 'cpu')
    bbb = torch.sum(m_out, dim=0, keepdim=False) / int(mol.GetNumAtoms())
    ccc = torch.sum(m_out, dim=0, keepdim=False)
    m_out = m_out.detach().numpy()
    g_out.append(bbb)
    for i in range(len(atom_dict)):
        if len(atom_dict[i]) == 0:
            a = [0] * 36
            a = torch.tensor(a, dtype=torch.float)
            g_out.append(a)
        else:
            # map.append(i)
            a = [0] * 36
            b = [0] * 36
            for j in atom_dict[i]:
                a = a + m_out[j]
            a = torch.tensor(a.tolist(), dtype=torch.float)
            g_out.append(a)

    # g_out.append(bbb)
    g_out.append(ccc)
    g_out = torch.stack(g_out)
    g_out = torch.unsqueeze(g_out,dim=0)
    g_out = g_out.to(device)
    return g_out


class M_conv1(nn.Module):
    def __init__(self,args):
        super(M_conv1,self).__init__()
        self.task_num = args.task_num
        self.k_conv = nn.Conv2d(in_channels=1, out_channels=2, kernel_size=3, dilation=1)
        self.k_convv = nn.Conv2d(in_channels=1, out_channels=2, kernel_size=3, dilation=1)
        self.k_convvv = nn.Conv2d(in_channels=1, out_channels=2, kernel_size=3, dilation=1)
        self.k_conv2 =nn.Conv2d(in_channels=2, out_channels=4, kernel_size=3, dilation=2)
        self.k_conv22 = nn.Conv2d(in_channels=2, out_channels=4, kernel_size=3, dilation=2)
        self.k_conv3 =nn.Conv2d(in_channels=4, out_channels=8, kernel_size=3, dilation=3)
        self.fc = nn.Sequential(
            nn.Linear(384, 300),
            nn.ReLU(),
            # nn.Linear(384, 167),
            # nn.ReLU(),
            # nn.Linear(192, 167),
        )
        # self.bam = ODConv2d(2,4,3)
        # self.bam1 = ODConv2d(8, 8, 5)
        self.drop = nn.Dropout(0.2)
        self.drop1 = nn.Dropout(0.2)
        self.sim = SimAM()
    def forward(self,g_outs):
        g_outs = self.sim(g_outs)
        c_o1 = self.k_conv(g_outs)
        c_o11 = self.drop(self.k_convv(g_outs))
        c_o111 = self.k_convvv(g_outs)
        co1 = (c_o1+c_o11+c_o111)/3
        c_o2 = self.k_conv2(F.relu(co1))
        c_o22 = self.drop1(self.k_conv22(F.relu(co1)))
        co2 = (c_o2+c_o22)/2
        c_o3 = self.k_conv3(F.relu(co2))
        cout = self.fc(c_o3.view(c_o3.size(0),-1))
        return cout

class Mutilayer(nn.Module):
    def __init__(self):
        super(Mutilayer,self).__init__()
        self.muti = MultiHeadSelfAttention(8,128,8)
        self.layn = nn.LayerNorm(8)
    def forward(self,b_fea):
        muti_o = self.muti(b_fea)
        b_out = self.layn(muti_o)
        return b_out

class Mpnnlayer2(nn.Module):  #纯过GCN
    def __init__(self):
        super(Mpnnlayer2,self).__init__()
        self.gconv = GCNConv(36,36)
        self.gconv2 = GCNConv(36, 36)
        self.gconv3 = GCNConv(36, 36)
        w1 = torch.ones(1)
        w2 = torch.ones(1)
        self.w1 = nn.Parameter(w1)
        self.w2 = nn.Parameter(w2)
        self.reset_gate = nn.Sequential(
            nn.Linear(36 * 2, 36),
            nn.Sigmoid()
        )
    def forward(self,e_fea,edge_in,edge_tup):
        device = torch.device('cuda:3' if torch.cuda.is_available() else 'cpu')
        fea = torch.unsqueeze(e_fea,dim=0)
        # fea1 = fea
        gcn_o = self.gconv(fea,edge_in) #第一次
        # gcn_o = F.relu(gcn_o) + self.w1 * fea1
        r = self.reset_gate(torch.cat((fea,gcn_o),2))
        gcn_o = gcn_o + fea * r
        gcn_oo = self.gconv2(gcn_o,edge_in) #第二次
        r = self.reset_gate(torch.cat((gcn_o, gcn_oo), 2))
        gcn_oo = gcn_oo + r * gcn_o
        gcn_out = self.gconv3(gcn_oo,edge_in)
        r = self.reset_gate(torch.cat((gcn_oo, gcn_out), 2))
        out = gcn_out + r * gcn_out
        out = torch.squeeze(out,dim=0)
        # oo = torch.cat((ro,ro1,ro2),dim=1)

        return out

#
# class Mpnnlayer2(nn.Module):  #纯过GCN
#     def __init__(self):
#         super(Mpnnlayer2,self).__init__()
#         self.gconv = GCNConv(36,36)
#         self.gconv2 = GCNConv(36, 36)
#         self.gconv3 = GCNConv(36, 36)
#         w1 = torch.ones(1)
#         w2 = torch.ones(1)
#         self.w1 = nn.Parameter(w1)
#         self.w2 = nn.Parameter(w2)
#         self.reset_gate = nn.Sequential(
#             nn.Linear(36 * 3, 36),
#             nn.Sigmoid()
#         )
#         self.update_gate = nn.Sequential(
#             nn.Linear(36 * 3, 36),
#             nn.Sigmoid()
#         )
#         self.tansform = nn.Sequential(
#             nn.Linear(36 * 3, 36),
#             nn.Tanh()
#         )
#     def forward(self,e_fea,edge_in,edge_tup):
#         device = torch.device('cuda:3' if torch.cuda.is_available() else 'cpu')
#         fea = torch.unsqueeze(e_fea,dim=0)
#         fea1 = fea
#         gcn_o = self.gconv(fea,edge_in) #第一次
#         gcn_o = self.pro(fea,gcn_o)
#         # gcn_o = F.relu(gcn_o) + self.w1 * fea1
#         gcn_oo = self.gconv2(gcn_o,edge_in) #第二次
#         # gcn_oo = F.relu(gcn_oo) + self.w2 * gcn_o
#         gcn_oo = self.pro(gcn_o,gcn_oo)
#         # gcn_out = F.relu (self.gconv3(gcn_oo,edge_in)) + gcn_oo
#         gcn_out = self.gconv3(gcn_oo,edge_in)
#         out = self.pro(gcn_oo,gcn_oo)
#         out = torch.squeeze(out,dim=0)
#         # oo = torch.cat((ro,ro1,ro2),dim=1)
#         return out
#
#     def pro(self,fea, gcn_o):
#         sc = gcn_o - fea
#         a = torch.cat((fea, gcn_o, sc), 2)
#         r = self.reset_gate(a)
#         z = self.update_gate(a)
#         joined_input = torch.cat((fea, gcn_o, r * sc), 2)
#         h_hat = self.tansform(joined_input)
#         output = (1 - z) * sc + z * h_hat
#         return  output












class MultiHeadSelfAttention(nn.Module):
    dim_in: int  # input dimension
    dim_k: int   # key and query dimension
    dim_v: int   # value dimension
    num_heads: int  # number of heads, for each head, dim_* = dim_* // num_heads

    def __init__(self, dim_in, dim_k, dim_v, num_heads=4):
        super(MultiHeadSelfAttention, self).__init__()
        assert dim_k % num_heads == 0 and dim_v % num_heads == 0, "dim_k and dim_v must be multiple of num_heads"
        self.dim_in = dim_in
        self.dim_k = dim_k
        self.dim_v = dim_v
        self.num_heads = num_heads
        self.linear_q = nn.Linear(dim_in, dim_k, bias=False)
        self.linear_k = nn.Linear(dim_in, dim_k, bias=False)
        self.linear_v = nn.Linear(dim_in, dim_v, bias=False)
        self._norm_fact = 1 / math.sqrt(dim_k // num_heads)

    def forward(self, x):
        # x: tensor of shape (batch, n, dim_in)
        batch, n, dim_in = x.shape
        assert dim_in == self.dim_in

        nh = self.num_heads
        dk = self.dim_k // nh  # dim_k of each head
        dv = self.dim_v // nh  # dim_v of each head

        q = self.linear_q(x).reshape(batch, n, nh, dk).transpose(1, 2)  # (batch, nh, n, dk)
        k = self.linear_k(x).reshape(batch, n, nh, dk).transpose(1, 2)  # (batch, nh, n, dk)
        v = self.linear_v(x).reshape(batch, n, nh, dv).transpose(1, 2)  # (batch, nh, n, dv)

        dist = torch.matmul(q, k.transpose(2, 3)) * self._norm_fact  # batch, nh, n, n
        dist = torch.softmax(dist, dim=-1)  # batch, nh, n, n

        att = torch.matmul(dist, v)  # batch, nh, n, dv
        att = att.transpose(1, 2).reshape(batch, n, self.dim_v)  # batch, n, dim_v
        return att






class ShareSepConv(nn.Module):
    def __init__(self, kernel_size):
        super(ShareSepConv, self).__init__()
        assert kernel_size % 2 == 1, 'kernel size should be odd'
        self.padding = (kernel_size - 1)//2#设置该大小的padding,能使得进行卷积后，输出的特征图的尺寸大小不变
        weight_tensor = torch.zeros(1, 1, kernel_size, kernel_size)#定义一个1个种类,一个通道，大小为kernel_size的卷积核
        weight_tensor[0, 0, (kernel_size-1)//2, (kernel_size-1)//2] = 1#将卷积核中间那个数值设为1
        self.weight = nn.Parameter(weight_tensor)#将其卷积核变为可学习的参数
        # print('self.weight_shape:',self.weight.shape)
        self.kernel_size = kernel_size

    def forward(self, x):
        inc = x.size(1)#获取输入特征图的通道数
        expand_weight = self.weight.expand(inc, 1, self.kernel_size, self.kernel_size).contiguous()#为那个共享的卷积核进行复制，复制到与输入特征图具有一样的通道数，输出也是该通道数
        return F.conv2d(input=x, weight=expand_weight,bias=None, stride=1, padding=self.padding, dilation=1, groups=inc)#对输入的特征图进行指定的卷积核进行卷积操作，group参数可以使得卷积核与输入的特征图的通道数不一致

#2.平滑空洞卷积，带有残差结构
class SmoothDilatedResidualBlock(nn.Module):
    def __init__(self, channel_num, dilation=1, group=1):
        super(SmoothDilatedResidualBlock, self).__init__()
        self.pre_conv1 = ShareSepConv(dilation*2-1)#在空洞卷积前执行SS,分离共享操作。
        self.conv1 = nn.Conv2d(channel_num, channel_num, 3, 1, padding=dilation, dilation=dilation, groups=group, bias=False)#空洞卷积，
        self.norm1 = nn.InstanceNorm2d(channel_num, affine=True)#实例化归一层

        self.pre_conv2 = ShareSepConv(dilation*2-1)
        self.conv2 = nn.Conv2d(channel_num, channel_num, 3, 1, padding=dilation, dilation=dilation, groups=group, bias=False)
        self.norm2 = nn.InstanceNorm2d(channel_num, affine=True)

    def forward(self, x):
        y = F.relu(self.norm1(self.conv1(self.pre_conv1(x))))
        y = self.norm2(self.conv2(self.pre_conv2(y)))
        return F.relu(x+y)





class Attention(nn.Module):
    def __init__(self, in_planes, out_planes, kernel_size, groups=1, reduction=0.0625, kernel_num=4, min_channel=16):
        super(Attention, self).__init__()
        attention_channel = max(int(in_planes * reduction), min_channel)
        self.kernel_size = kernel_size
        self.kernel_num = kernel_num
        self.temperature = 1.0

        self.avgpool = nn.AdaptiveAvgPool2d(1)
        self.fc = nn.Conv2d(in_planes, attention_channel, 1, bias=False)
        self.bn = nn.BatchNorm2d(attention_channel)
        self.relu = nn.ReLU(inplace=True)

        self.channel_fc = nn.Conv2d(attention_channel, in_planes, 1, bias=True)
        self.func_channel = self.get_channel_attention

        if in_planes == groups and in_planes == out_planes:  # depth-wise convolution
            self.func_filter = self.skip
        else:
            self.filter_fc = nn.Conv2d(attention_channel, out_planes, 1, bias=True)
            self.func_filter = self.get_filter_attention

        if kernel_size == 1:  # point-wise convolution
            self.func_spatial = self.skip
        else:
            self.spatial_fc = nn.Conv2d(attention_channel, kernel_size * kernel_size, 1, bias=True)
            self.func_spatial = self.get_spatial_attention

        if kernel_num == 1:
            self.func_kernel = self.skip
        else:
            self.kernel_fc = nn.Conv2d(attention_channel, kernel_num, 1, bias=True)
            self.func_kernel = self.get_kernel_attention

        self._initialize_weights()

    def _initialize_weights(self):
        for m in self.modules():
            if isinstance(m, nn.Conv2d):
                nn.init.kaiming_normal_(m.weight, mode='fan_out', nonlinearity='relu')
                if m.bias is not None:
                    nn.init.constant_(m.bias, 0)
            if isinstance(m, nn.BatchNorm2d):
                nn.init.constant_(m.weight, 1)
                nn.init.constant_(m.bias, 0)

    def update_temperature(self, temperature):
        self.temperature = temperature

    @staticmethod
    def skip(_):
        return 1.0

    def get_channel_attention(self, x):
        channel_attention = torch.sigmoid(self.channel_fc(x).view(x.size(0), -1, 1, 1) / self.temperature)
        return channel_attention

    def get_filter_attention(self, x):
        filter_attention = torch.sigmoid(self.filter_fc(x).view(x.size(0), -1, 1, 1) / self.temperature)
        return filter_attention

    def get_spatial_attention(self, x):
        spatial_attention = self.spatial_fc(x).view(x.size(0), 1, 1, 1, self.kernel_size, self.kernel_size)
        spatial_attention = torch.sigmoid(spatial_attention / self.temperature)
        return spatial_attention

    def get_kernel_attention(self, x):
        kernel_attention = self.kernel_fc(x).view(x.size(0), -1, 1, 1, 1, 1)
        kernel_attention = F.softmax(kernel_attention / self.temperature, dim=1)
        return kernel_attention

    def forward(self, x):
        x = self.avgpool(x)
        x = self.fc(x)
        x = self.bn(x)
        x = self.relu(x)
        return self.func_channel(x), self.func_filter(x), self.func_spatial(x), self.func_kernel(x)


class ODConv2d(nn.Module):
    def __init__(self, in_planes, out_planes, kernel_size, stride=1, padding=0, dilation=1, groups=1,
                 reduction=0.0625, kernel_num=4):
        super(ODConv2d, self).__init__()
        self.in_planes = in_planes
        self.out_planes = out_planes
        self.kernel_size = kernel_size
        self.stride = stride
        self.padding = padding
        self.dilation = dilation
        self.groups = groups
        self.kernel_num = kernel_num
        self.attention = Attention(in_planes, out_planes, kernel_size, groups=groups,
                                   reduction=reduction, kernel_num=kernel_num)
        self.weight = nn.Parameter(torch.randn(kernel_num, out_planes, in_planes // groups, kernel_size, kernel_size),
                                   requires_grad=True)
        self._initialize_weights()

        if self.kernel_size == 1 and self.kernel_num == 1:
            self._forward_impl = self._forward_impl_pw1x
        else:
            self._forward_impl = self._forward_impl_common

    def _initialize_weights(self):
        for i in range(self.kernel_num):
            nn.init.kaiming_normal_(self.weight[i], mode='fan_out', nonlinearity='relu')

    def update_temperature(self, temperature):
        self.attention.update_temperature(temperature)

    def _forward_impl_common(self, x):
        # Multiplying channel attention (or filter attention) to weights and feature maps are equivalent,
        # while we observe that when using the latter method the models will run faster with less gpu memory cost.
        channel_attention, filter_attention, spatial_attention, kernel_attention = self.attention(x)
        batch_size, in_planes, height, width = x.size()
        x = x * channel_attention
        x = x.reshape(1, -1, height, width)
        aggregate_weight = spatial_attention * kernel_attention * self.weight.unsqueeze(dim=0)
        aggregate_weight = torch.sum(aggregate_weight, dim=1).view(
            [-1, self.in_planes // self.groups, self.kernel_size, self.kernel_size])
        output = F.conv2d(x, weight=aggregate_weight, bias=None, stride=self.stride, padding=self.padding,
                          dilation=self.dilation, groups=self.groups * batch_size)
        output = output.view(batch_size, self.out_planes, output.size(-2), output.size(-1))
        output = output * filter_attention
        return output

    def _forward_impl_pw1x(self, x):
        channel_attention, filter_attention, spatial_attention, kernel_attention = self.attention(x)
        x = x * channel_attention
        output = F.conv2d(x, weight=self.weight.squeeze(dim=0), bias=None, stride=self.stride, padding=self.padding,
                          dilation=self.dilation, groups=self.groups)
        output = output * filter_attention
        return output

    def forward(self, x):
        return self._forward_impl(x)


class SimAM(torch.nn.Module):
    def __init__(self, e_lambda=1e-4):
        super(SimAM, self).__init__()

        self.activaton = nn.Sigmoid()
        self.e_lambda = e_lambda

    def __repr__(self):
        s = self.__class__.__name__ + '('
        s += ('lambda=%f)' % self.e_lambda)
        return s

    @staticmethod
    def get_module_name():
        return "simam"

    def forward(self, x):
        b, c, h, w = x.size()

        n = w * h - 1

        x_minus_mu_square = (x - x.mean(dim=[2, 3], keepdim=True)).pow(2)
        y = x_minus_mu_square / (4 * (x_minus_mu_square.sum(dim=[2, 3], keepdim=True) / n + self.e_lambda)) + 0.5

        return x * self.activaton(y)


class LayerNorm(nn.Module):
    def __init__(self, hidden_size, eps=1e-12):
        """Construct a layernorm module in the TF style (epsilon inside the square root).
        """
        super(LayerNorm, self).__init__()
        self.weight = nn.Parameter(torch.ones(hidden_size))
        self.bias = nn.Parameter(torch.zeros(hidden_size))
        self.variance_epsilon = eps

    def forward(self, x):
        u = x.mean(-1, keepdim=True)
        s = (x - u).pow(2).mean(-1, keepdim=True)
        x = (x - u) / torch.sqrt(s + self.variance_epsilon)
        return self.weight * x + self.bias


class SelfAttention(nn.Module):
    def __init__(self, num_attention_heads, input_size, hidden_size, hidden_dropout_prob):
        super(SelfAttention, self).__init__()
        if hidden_size % num_attention_heads != 0:
            raise ValueError(
                "The hidden size (%d) is not a multiple of the number of attention "
                "heads (%d)" % (hidden_size, num_attention_heads))
        self.num_attention_heads = num_attention_heads
        self.attention_head_size = int(hidden_size / num_attention_heads)
        self.all_head_size = hidden_size

        self.query = nn.Linear(input_size, self.all_head_size)
        self.key = nn.Linear(input_size, self.all_head_size)
        self.value = nn.Linear(input_size, self.all_head_size)

        self.attn_dropout = nn.Dropout(0.2)

        # 做完self-attention 做一个前馈全连接 LayerNorm 输出
        self.dense = nn.Linear(hidden_size, hidden_size)
        self.LayerNorm = LayerNorm(hidden_size, eps=1e-12)
        self.out_dropout = nn.Dropout(hidden_dropout_prob)

    def transpose_for_scores(self, x):
        new_x_shape = x.size()[:-1] + (self.num_attention_heads, self.attention_head_size)
        x = x.view(*new_x_shape)
        return x.permute(0, 2, 1, 3)

    def forward(self, input_tensor):
        mixed_query_layer = self.query(input_tensor)
        mixed_key_layer = self.key(input_tensor)
        mixed_value_layer = self.value(input_tensor)

        query_layer = self.transpose_for_scores(mixed_query_layer)
        key_layer = self.transpose_for_scores(mixed_key_layer)
        value_layer = self.transpose_for_scores(mixed_value_layer)

        # Take the dot product between "query" and "key" to get the raw attention scores.
        attention_scores = torch.matmul(query_layer, key_layer.transpose(-1, -2))

        attention_scores = attention_scores / math.sqrt(self.attention_head_size)
        # Apply the attention mask is (precomputed for all layers in BertModel forward() function)
        # [batch_size heads seq_len seq_len] scores
        # [batch_size 1 1 seq_len]

        # attention_scores = attention_scores + attention_mask

        # Normalize the attention scores to probabilities.
        attention_probs = nn.Softmax(dim=-1)(attention_scores)
        # This is actually dropping out entire tokens to attend to, which might
        # seem a bit unusual, but is taken from the original Transformer paper.
        # Fixme
        attention_probs = self.attn_dropout(attention_probs)
        context_layer = torch.matmul(attention_probs, value_layer)
        context_layer = context_layer.permute(0, 2, 1, 3).contiguous()
        new_context_layer_shape = context_layer.size()[:-2] + (self.all_head_size,)
        context_layer = context_layer.view(*new_context_layer_shape)
        hidden_states = self.dense(context_layer)
        hidden_states = self.out_dropout(hidden_states)
        hidden_states = self.LayerNorm(hidden_states + input_tensor)

        return hidden_states
