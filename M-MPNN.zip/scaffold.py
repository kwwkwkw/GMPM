from collections import defaultdict
import logging
import random
import numpy as np
from rdkit import Chem
from rdkit.Chem.Scaffolds import MurckoScaffold
import csv
from data import MoleDataSet, MoleData


def generate_scaffold(mol,include_chirality=False):
    mol = Chem.MolFromSmiles(mol) if type(mol) == str else mol
    scaffold = MurckoScaffold.MurckoScaffoldSmiles(mol=mol, includeChirality=include_chirality)

    return scaffold


def scaffold_to_smiles(mol,use_indices=False):
    scaffolds = defaultdict(set)
    for i, one in enumerate(mol):
        scaffold = generate_scaffold(one)
        if use_indices:
            scaffolds[scaffold].add(i)
        else:
            scaffolds[scaffold].add(one)

    return scaffolds


def scaffold_split(data,size,seed):
    assert sum(size) == 1

    # Split
    train_size, val_size, test_size = size[0] * len(data), size[1] * len(data), size[2] * len(data)
    train, val, test = [], [], []
    train_scaffold_count, val_scaffold_count, test_scaffold_count = 0, 0, 0

    # Map from scaffold to index in the data
    scaffold_to_indices = scaffold_to_smiles(data.mol(), use_indices=True)

    index_sets = list(scaffold_to_indices.values())
    big_index_sets = []
    small_index_sets = []
    for index_set in index_sets:
        if len(index_set) > val_size / 2 or len(index_set) > test_size / 2:
            big_index_sets.append(index_set)
        else:
            small_index_sets.append(index_set)
    random.seed(seed)
    random.shuffle(big_index_sets)
    random.shuffle(small_index_sets)
    index_sets = big_index_sets + small_index_sets

    for index_set in index_sets:
        if len(train) + len(index_set) <= train_size:
            train += index_set
            train_scaffold_count += 1
        elif len(val) + len(index_set) <= val_size:
            val += index_set
            val_scaffold_count += 1
        else:
            test += index_set
            test_scaffold_count += 1


    
    # Map from indices to data
    train = [data[i] for i in train]
    val = [data[i] for i in val]
    test = [data[i] for i in test]

    return MoleDataSet(train), MoleDataSet(val), MoleDataSet(test)


def load_data(path):
    with open(path) as file:
        reader = csv.reader(file)
        next(reader)
        lines = []
        for line in reader:
            lines.append(line)
        data = []
        for line in lines:
            one = MoleData(line)
            data.append(one)
        data = MoleDataSet(data)

        fir_data_len = len(data)
        data_val = []
        smi_exist = []
        for i in range(fir_data_len):
            if data[i].mol is not None:
                smi_exist.append(i)
        data_val = MoleDataSet([data[i] for i in smi_exist])
        now_data_len = len(data_val)
        print('There are ', now_data_len, ' smiles in total.')
        if fir_data_len - now_data_len > 0:
            print('There are ', fir_data_len, ' smiles first, but ', fir_data_len - now_data_len,
                  ' smiles is invalid.  ')

    return data_val


def split_data(data, type, size, seed):
    assert len(size) == 3
    assert sum(size) == 1

    if type == 'random':
        data.random_data(seed)
        train_size = int(size[0] * len(data))
        val_size = int(size[1] * len(data))
        train_val_size = train_size + val_size
        train_data = data[:train_size]
        val_data = data[train_size:train_val_size]
        test_data = data[train_val_size:]
        return MoleDataSet(train_data), MoleDataSet(val_data), MoleDataSet(test_data)
    elif type == 'scaffold':
        return scaffold_split(data,size,seed)
    else:
        raise ValueError('Split_type is Error.')


def get_label_scaler(data):
    smile = data.smile()
    label = data.label()

    label = np.array(label).astype(float)
    ave = np.nanmean(label, axis=0)
    ave = np.where(np.isnan(ave), np.zeros(ave.shape), ave)
    std = np.nanstd(label, axis=0)
    std = np.where(np.isnan(std), np.ones(std.shape), std)
    std = np.where(std == 0, np.ones(std.shape), std)

    change_1 = (label - ave) / std
    label_changed = np.where(np.isnan(change_1), None, change_1)
    label_changed.tolist()
    data.change_label(label_changed)

    return [ave, std]


def get_task_name(path):
    task_name = get_header(path)[1:]
    return task_name


def get_header(path):
    with open(path, encoding="gbk") as file:
        header = next(csv.reader(file))

    return header


