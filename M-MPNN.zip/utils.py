import copy
from argparse import Namespace
from rdkit.Chem import rdMolTransforms
import pandas as pd
from rdkit import Chem
import torch
import numpy as np
import warnings

from rdkit.Chem import AllChem
from rdkit.Chem.Scaffolds import MurckoScaffold
from torch.optim.lr_scheduler import _LRScheduler

atom_type_max = 100
atom_f_dim = 36
# atom_features_define = {
#     'atom_symbol': list(range(atom_type_max)),
#     'degree': [0, 1, 2, 3, 4, 5],
#     'formal_charge': [-1, -2, 1, 2, 0],
#     'charity_type': [0, 1, 2, 3],
#     'hydrogen': [0, 1, 2, 3, 4],
#     'hybridization': [
#         Chem.rdchem.HybridizationType.SP,
#         Chem.rdchem.HybridizationType.SP2,
#         Chem.rdchem.HybridizationType.SP3,
#         Chem.rdchem.HybridizationType.SP3D,
#         Chem.rdchem.HybridizationType.SP3D2
#     ],}


smile_changed = {}
def one_of_k_encoding(x, allowable_set):
    if x not in allowable_set:
        raise Exception("input {0} not in allowable set{1}:".format(
            x, allowable_set))
    return [x == s for s in allowable_set]


def one_of_k_encoding_unk(x, allowable_set):
    """Maps inputs not in the allowable set to the last element."""
    if x not in allowable_set:
        x = allowable_set[-1]
    return [x == s for s in allowable_set]

def bond_features(bond):   #获取原子边
    bond_feats = [0]*28
    bond_feats += one_of_k_encoding_unk(bond.GetBondType(), [Chem.rdchem.BondType.SINGLE,Chem.rdchem.BondType.DOUBLE,
                                                        Chem.rdchem.BondType.TRIPLE,  Chem.rdchem.BondType.AROMATIC])
    bond_feats += [bond.GetIsConjugated()]
    bond_feats += [bond.IsInRing()]
    # bond_feats += one_of_k_encoding_unk(str(bond.GetStereo()),["STEREONONE", "STEREOANY", "STEREOZ", "STEREOE"])
    # a = str(bond.GetStereo())
    bond_feats += [0]*2
    return np.array(bond_feats,dtype=int)


def get_atom_features(atom):
    atom_type = ['B','C','O','N','F','S','Cl','Br','I','P','other']
    atom_attributes = one_of_k_encoding_unk(atom,atom_type)
    atom_attributes += one_of_k_encoding_unk(len(atom.GetNeighbors()),[0, 1, 2, 3, 4, 5,])
    atom_attributes += one_of_k_encoding_unk(atom.GetHybridization(),
                            [Chem.rdchem.HybridizationType.SP, Chem.rdchem.HybridizationType.SP2,
                             Chem.rdchem.HybridizationType.SP3, Chem.rdchem.HybridizationType.SP3D,
                             Chem.rdchem.HybridizationType.SP3D2, 'other'])
    atom_attributes += [atom.GetIsAromatic()]
    atom_attributes += [atom.IsInRing()]
    # atom_attributes += [0,0,0,0,0,0]
    atom_attributes += [0]
    return np.array(atom_attributes, dtype=float) #28

# def featurize_mol(mol):   #GCN用到的图卷积的矩阵
#     node_features = np.array([get_atom_features(atom) for atom in mol.GetAtoms()])
#     # mol_bond_features = []
#     # row, col = [], []
#     # for bond in mol.GetBonds():
#     #     bond_feats = bond_features(bond)
#     #     mol_bond_features.append(bond_feats)
#     #     start, end = bond.GetBeginAtomIdx(), bond.GetEndAtomIdx()
#     #     node_features[start] = node_features[start] + bond_feats
#     #     node_features[end] = node_features[end] + bond_feats
#     #     row += [start, end]
#     #     col += [end, start]
#     #
#     # edge_index = torch.LongTensor([row, col])
#     # adj_matrix = np.eye(mol.GetNumAtoms())
#     #
#     # for bond in mol.GetBonds():
#     #     begin_atom = bond.GetBeginAtom().GetIdx()
#     #     end_atom = bond.GetEndAtom().GetIdx()
#     #     adj_matrix[begin_atom, end_atom] = adj_matrix[end_atom, begin_atom] = 1
#     return node_features

def featurize_mol(mol):   #最后一位为摩根指纹标识
    node_features = np.array([get_atom_features(atom) for atom in mol.GetAtoms()])
    info = {}
    fp = AllChem.GetMorganFingerprint(mol, 2, bitInfo=info)
    for k in info:  # 取出键，也就是指纹对的标识
        for i in range(len(info[k])):  # 遍历拥有该指纹的子结构
            #         print(info[k][i])
            atmo = info[k][i][0]
            radi = info[k][i][1]
            if radi == 0:
                amap = {}
                radis = radi + 1
                env = Chem.FindAtomEnvironmentOfRadiusN(mol, radis, atmo)
                submol = Chem.PathToSubmol(mol, env, atomMap=amap)
                aaa = list(amap.items())
                for j in aaa:  # 子结构半径为0的加值
                    #                 print(j)
                    if j[0] == atmo:
                        z = j[1]
                        node_features[z][-1] = node_features[z][-1] + 1
                    else:
                        continue
            else:
                amap = {}
                env = Chem.FindAtomEnvironmentOfRadiusN(mol, radi, atmo)
                submol = Chem.PathToSubmol(mol, env, atomMap=amap)
                aaa = list(amap.items())
                for j in aaa:  # 子结构半径不为0的加值
                    #                 print(j)
                    if j[0] == atmo:
                        z = j[1]
                        node_features[z][-1] = node_features[z][-1] + 0.5
                    else:
                        z = j[1]
                        node_features[z][-1] = node_features[z][-1] + 0.25
    return node_features  #np.arrray

def edge_in(mol):
    row, col = [], []
    for bond in mol.GetBonds():
        start, end = bond.GetBeginAtomIdx(), bond.GetEndAtomIdx()
        row += [start, end]
        col += [end, start]
    edge_index = torch.LongTensor([row, col])
    return edge_index

class NoamLR(_LRScheduler):
    def __init__(self,optimizer,warmup_epochs,total_epochs,steps_per_epoch,
                 init_lr,max_lr,final_lr):
        assert len(optimizer.param_groups) == len(warmup_epochs) == len(total_epochs) == len(init_lr) == \
               len(max_lr) == len(final_lr)

        self.num_lrs = len(optimizer.param_groups)

        self.optimizer = optimizer
        self.warmup_epochs = np.array(warmup_epochs)
        self.total_epochs = np.array(total_epochs)
        self.steps_per_epoch = steps_per_epoch
        self.init_lr = np.array(init_lr)
        self.max_lr = np.array(max_lr)
        self.final_lr = np.array(final_lr)

        self.current_step = 0
        self.lr = init_lr
        self.warmup_steps = (self.warmup_epochs * self.steps_per_epoch).astype(int)
        self.total_steps = self.total_epochs * self.steps_per_epoch
        self.linear_increment = (self.max_lr - self.init_lr) / self.warmup_steps

        self.exponential_gamma = (self.final_lr / self.max_lr) ** (1 / (self.total_steps - self.warmup_steps))

        super(NoamLR, self).__init__(optimizer)

    def get_lr(self):
        return list(self.lr)

    def step(self,current_step=None):
        if current_step is not None:
            self.current_step = current_step
        else:
            self.current_step += 1

        for i in range(self.num_lrs):
            if self.current_step <= self.warmup_steps[i]:
                self.lr[i] = self.init_lr[i] + self.current_step * self.linear_increment[i]
            elif self.current_step <= self.total_steps[i]:
                self.lr[i] = self.max_lr[i] * (self.exponential_gamma[i] ** (self.current_step - self.warmup_steps[i]))
            else:
                self.lr[i] = self.final_lr[i]

            self.optimizer.param_groups[i]['lr'] = self.lr[i]

def featurize_mol2(mol):   #倒数第8位为摩根指纹标识  共33维
    node_features = [get_atom_features2(atom) for atom in mol.GetAtoms()]
    e = []
    b = []
    atom_dict=[[],[],[],[],[],[],[],[],[],[],[],[]]
    for i in range(len(node_features)):
        smi = Chem.MolToSmiles(mol)
        j = node_features[i].index(1)
        atom_dict[j].append(i)
    mol_bond_features = []
    row, col = [], []
    forw,reve = [],[]
    edge_flag = {}
    # edge_tup =[]
    nam = mol.GetNumAtoms()
    for bond in mol.GetBonds():
        bond_feats = bond_features(bond)
        mol_bond_features.append(bond_feats)
        start, end = bond.GetBeginAtomIdx(), bond.GetEndAtomIdx()
        node_features[start] = (node_features[start] + bond_feats).tolist()
        node_features[end] = (node_features[end] + bond_feats).tolist()
        row += [start,end]
        col += [end,start]
        forw.append((start,end))
        reve.append((end,start))
    edge_index = torch.LongTensor([row, col])
    edge_tup = [0]*len(forw)
    edge_tup2 = [0] * (len(forw)*2)
    bonds = mol.GetBonds()
    info = {}
    node_features1 = copy.deepcopy(node_features)
    fp = AllChem.GetMorganFingerprint(mol, 2, bitInfo=info)
    mol_pair_dict = {}
    for k in info:  # 取出键，也就是指纹对的标识
        nm = len(info[k])
            #         print(info[k][i])
        atmo = info[k][0][0]
        radi = info[k][0][1]
        if radi == 0:
            continue
        else:
            amap = {}
            env = Chem.FindAtomEnvironmentOfRadiusN(mol, radi, atmo)
            submol = Chem.PathToSubmol(mol, env, atomMap=amap)
            smi = Chem.MolToSmiles(submol)
            fl = mol.HasSubstructMatch(submol)
            hit_at = mol.GetSubstructMatches(submol)
            if len(hit_at) == 1:
                for c in hit_at:
                    for j in c:  # 子结构半径不为0的加值
                        z = j
                        if z < nam:
                            node_features[z][-9] = node_features[z][-9] + 1
                    # hit_bond = []
                    # for bond in submol.GetBonds():
                    #     aid1 = c[bond.GetBeginAtomIdx()]
                    #     aid2 = c[bond.GetEndAtomIdx()]
                    #     hit_bond.append(mol.GetBondBetweenAtoms(aid1, aid2).GetIdx())
                    # for w in hit_bond:
                    #     bond = bonds[w]
                    #     start, end = bond.GetBeginAtomIdx(), bond.GetEndAtomIdx()
                    #     # bl = round(rdMolTransforms.GetBondLength(conf,start,end),2)
                    #     # print(bl)
                    #     node_features[start][-1] = node_features[start][-1] + 0.5
                    #     node_features[end][-1] = node_features[end][-1] + 0.5
    e_fea = [i[:28] for i in node_features]
    b_fea =[i[28:] for i in node_features]
    # e = [i[-1] for i in e_fea]
    # b = [i[-1] for i in b_fea]
    # e = torch.tensor(e)
    # e = torch.reshape(e,(-1,1))
    # b = torch.tensor(b)
    # awm = e * b
    # return e_fea,b_fea,edge_flag,edge_index,edge_tup2,atom_dict,num  #np.arrray
    return e_fea,b_fea,edge_index,edge_tup2,atom_dict,node_features,node_features1

def get_atom_features2(atom):
    atom_type = ['B','C','O','N','F','S','Cl','Br','I','P','Si','other']
    # atom_type = ['B', 'C', 'F', 'O', 'S', 'N', 'Cl', 'Br', 'I-', 'P', 'Si', 'other']
    atom_attributes = one_of_k_encoding_unk(atom.GetSymbol(),atom_type)
    atom_attributes += one_of_k_encoding_unk(len(atom.GetNeighbors()),[0, 1, 2, 3, 4, 5, 6])
    atom_attributes += one_of_k_encoding_unk(atom.GetHybridization(),
                            [Chem.rdchem.HybridizationType.SP, Chem.rdchem.HybridizationType.SP2,
                             Chem.rdchem.HybridizationType.SP3, Chem.rdchem.HybridizationType.SP3D,
                             Chem.rdchem.HybridizationType.SP3D2, 'other'])
    atom_attributes += [atom.GetIsAromatic()]
    atom_attributes += [atom.IsInRing()]
    # atom_attributes += [atom.GetNumRadicalElectrons()]
    # try:
    #     atom_attributes += one_of_k_encoding_unk(atom.GetProp('_CIPCode'),['R', 'S']) + [atom.HasProp('_ChiralityPossible')]
    # except:
    #     atom_attributes += [False, False] + [atom.HasProp('_ChiralityPossible')]
    # atom_attributes += [atom.NumRadicalElectrons()]
    # atom_attributes += [0,0,0,0,0,0]
    atom_attributes += [0]*9
    return atom_attributes



if __name__ == '__main__':
    df = pd.read_csv("D:/re/Data/MoleculeNet/bace.csv")
    x= df.SMILES.values
    smi = x[21]
    mol = Chem.MolFromSmiles(smi)
    fea = featurize_mol2(mol)
    # for smi in x:
    #     mol = Chem.MolFromSmiles(smi)
    #     fea = featurize_mol(mol)
    print(fea)