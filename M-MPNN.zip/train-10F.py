import math
from argparse import Namespace
from logging import Logger, info, debug
import os
import csv
import numpy as np
import sklearn
import torch
from sklearn import metrics
from sklearn.metrics import roc_auc_score
from torch.optim import Adam
from torch.optim.lr_scheduler import ExponentialLR
import random
from scaffold import  get_task_name, load_data, split_data, get_label_scaler
from modell import Mmpnn
from data import MoleDataSet
import torch.nn as nn
from utils import NoamLR
from args import set_train_argument


def epoch_train(model, data, loss_f, optimizer,  seed, batchsize,scheduler=None):
    model.train() #有dropout和norm时用，用来提前启动一部分网络
    total = sum([param.nelement() for param in model.parameters()])
    print(total)
    data.random_data(seed)
    loss_sum = 0
    data_used = 0
    iter_step = batchsize
    device = torch.device('cuda:2' if torch.cuda.is_available() else 'cpu')

    for i in range(0, len(data), iter_step):
        if data_used + iter_step > len(data):
            break
        # model.eval()
        # model.stage4_xx.train()
        # model.pred_xx.train()
        data_now = MoleDataSet(data[i:i + iter_step])
        smile = data_now.smile()
        """
        AE时用的
        label = data_now.get_fea().float()
        mask = torch.Tensor([[x is not None for x in tb] for tb in label])  #统计有标签的数据标为1
        label = label.view(label.size(0),-1)
        label = torch.sum(label,dim=1)
        target = label
        """
        label = data_now.label()
        mask = torch.Tensor([[x is not None for x in tb] for tb in label])
        target = torch.Tensor([[0 if x is None else x for x in tb] for tb in label])

        if next(model.parameters()).is_cuda:
            mask, target = mask.to(device), target.to(device)

        weight = torch.ones(target.shape)
        if args.cuda:
            weight = weight.to(device)

        model.zero_grad()
        pred = model(smile)
        loss = loss_f(pred,target) * weight * mask
        loss = loss.sum() / mask.sum()
        loss_sum += loss.item()
        data_used += len(smile)
        loss.backward()
        optimizer.step()

        if isinstance(scheduler, NoamLR):
            scheduler.step()

    if isinstance(scheduler, ExponentialLR):
        scheduler.step()
    return loss_sum


def predict(model, data, batch_size):
    model.eval() #不启用dropout和norm时使用
    pred = []
    data_total = len(data)

    for i in range(0, data_total, batch_size):
        data_now = MoleDataSet(data[i:i + batch_size])
        smile = data_now.smile()

        with torch.no_grad():
            pred_now = model(smile)

        pred_now = pred_now.data.cpu().numpy()

        # if scaler is not None:
        #     ave = scaler[0]
        #     std = scaler[1]
        #     pred_now = np.array(pred_now).astype(float)
        #     change_1 = pred_now * std + ave
        #     pred_now = np.where(np.isnan(change_1), None, change_1)

        pred_now = pred_now.tolist()
        pred.extend(pred_now)

    return pred


def mti_auc(pred,label,task_num):
    assert len(pred) == len(label)
    aucs = []
    for i in range(task_num):
        exec('pred{} = []'.format(i))
        exec('label{} = []'.format(i))
    for i in range(len(pred)):
        for j in range(task_num):
            exec('pred{}.append(pred[i][j])'.format(j))
            exec('label{}.append(label[i][j])'.format(j))
    for i in range(task_num):
        exec('aucs.append(roc_auc_score(label{},pred{}))'.format(i,i))
    return aucs

def choice_loss(args):
    if args.dataset_type == 'regression':
        loss_f = nn.MSELoss(reduction='none')
    elif args.is_multitask == 0:
        loss_f = nn.BCEWithLogitsLoss()
    else:
        loss_f = nn.CrossEntropyLoss()
    return loss_f

def train(args):
    print("start loading data")
    path1 = args.data_path
    data = load_data(path1)
    seed = args.seed
    batchsize = args.batchsize
    split_type = args.split_type
    split_ratio = args.split_ratio
    dataset_type = args.dataset_type
    args.task_num = data.task_num()
    task_num = args.task_num
    args.task_names = get_task_name(args.data_path)
    if args.task_num > 1:
        args.is_multitask = 1
    data, val_data, test_data = split_data(data, split_type, split_ratio, seed)

    """-----------------------------5折交叉验证部分-----------------------------------"""
    k = 10
    begin = 0
    l = int(len(data)*0.1)
    end = l - 1
    # data.random_data(seed)
    test_re = []
    for i in range(k):
        test_data = MoleDataSet(data[begin:end])
        # train_data = MoleDataSet([x for x in data if x not in test_data])
        all_data = [x for x in data if x not in test_data]
        train_len = int(len(all_data)*0.95) - 1
        train_data = MoleDataSet(all_data[:train_len])
        train_len = train_len+1
        val_data = MoleDataSet(all_data[train_len:])
        begin = end + 1
        end = l * (i+2) - 1
        model = Mmpnn(args)
        optimizer = torch.optim.Adam(filter(lambda p: p.requires_grad, model.parameters()), lr=0.001)
        scheduler = NoamLR(optimizer=optimizer, warmup_epochs=[args.warmup_epochs],
                           total_epochs=None or [args.epoch] * args.num_lrs,
                           steps_per_epoch=len(train_data) // args.batchsize, init_lr=[args.init_lr],
                           max_lr=[args.max_lr],
                           final_lr=[args.final_lr])

        loss_f = choice_loss(args)
        print("tring model")
        device = torch.device('cuda:2' if torch.cuda.is_available() else 'cpu')
        model = model.to(device)
        epoch = args.epoch
        early_stopping = EarlyStopping()
        bepoch = 0
        all_loss = 100
        aucc = 0
        for i in range(epoch):
            print("Epoch:{}".format(i))
            train_loss = epoch_train(model, train_data, loss_f, optimizer, seed, batchsize, scheduler=scheduler)
            train_pred = predict(model, train_data, batchsize)
            train_label = train_data.label()
            train_target = torch.Tensor([[0 if x is None else x for x in tb] for tb in train_label])
            val_label = val_data.label()
            mask = torch.Tensor([[x is not None for x in tb] for tb in val_label])
            val_target = torch.Tensor([[0 if x is None else x for x in tb] for tb in val_label])
            val_pred = predict(model, val_data, batchsize)
            val_pred = torch.tensor(val_pred)
            weight = torch.ones(val_target.shape)
            loss = loss_f(val_pred, val_target) * weight * mask
            loss = loss.sum() / mask.sum()
            if dataset_type == 'classification':
                train_loss = train_loss
                val_loss = loss
                if task_num == 1:
                    train_auc = roc_auc_score(train_label, train_pred)
                    val_auc = roc_auc_score(val_label, val_pred)
                    print("train_auc:", train_auc)
                    print("val_auc", val_auc)
                    if val_auc > aucc:
                      aucc = val_auc
                      bepoch = i
                      save_path = args.save_path
                      save_model(os.path.join(save_path, 'model22.pt'), model)
                else:
                    train_auc = mti_auc(train_pred, train_label, task_num)
                    val_auc = mti_auc(val_pred, val_label, task_num)
                    print("train_auc:", np.mean(train_auc))
                    print("val_auc", np.mean(val_auc))
                    for i, one in enumerate(args.task_names):
                        print("{}_train_auc:{}".format(one, train_auc[i]))
                        print("{}_val_auc:{}".format(one, val_auc[i]))
                    if np.mean(val_auc) > aucc:
                      aucc = np.mean(val_auc)
                      bepoch = i
                      save_path = args.save_path
                      save_model(os.path.join(save_path, 'model22.pt'), model)
                
            else:
                train_loss = math.sqrt(train_loss)
                val_loss = math.sqrt(loss)
                if val_loss < all_loss:
                    all_loss = val_loss
                    bepoch = i
                    save_path = args.save_path
                    save_model(os.path.join(save_path, 'model22.pt'), model)
            print("train_loss:{},val_loss:{}".format(train_loss, val_loss))
            print("lr = ", optimizer.state_dict()['param_groups'][0]['lr'])
            early_stopping(val_loss, model)# 达到早停止条件时，early_stop会被置为True
            if early_stopping.early_stop:
                print("Early stopping")
                break  # 跳出迭代，结束训练
        print("best epoch:", bepoch)
        path = args.save_path + "model22.pt"
        model = load_model(path, args)
        test_pred = torch.tensor(predict(model, test_data, batchsize))
        test_label = torch.tensor(test_data.label())
        mask = torch.Tensor([[x is not None for x in tb] for tb in test_label])
        target = torch.Tensor([[0 if x is None else x for x in tb] for tb in test_label])
        weight = torch.ones(target.shape)
        loss = loss_f(test_pred, target) * weight * mask
        loss = loss.sum() / mask.sum()
        if dataset_type == 'classification':
            test_loss = loss
            if task_num == 1:
                test_auc = roc_auc_score(target, test_pred)
                test_re.append(test_auc)
                print("test_auc:", test_auc)
            else:
                test_auc = mti_auc(test_pred, test_label, task_num)
                print("test_auc", np.mean(test_auc))
                test_re.append(np.mean(test_auc))
                for i, one in enumerate(args.task_names):
                    print("{}_train_auc:{}".format(one, test_auc[i]))
        else:
            test_loss = torch.sqrt(loss)
            test_re.append(test_loss)
        print("test_loss = ", test_loss)
    print("交叉验证的测试集结果是：",np.mean(test_re))
    """-----------------------------------------------------------------------------"""

def load_model(path,pred_args):
    state = torch.load(path, map_location=lambda storage, loc: storage)
    # args = state['args']

    if pred_args is not None:
        for key, value in vars(pred_args).items():
            if not hasattr(args, key):
                setattr(args, key, value)

    state_dict = state['state_dict']

    model = Mmpnn(args)
    model_state_dict = model.state_dict()

    load_state_dict = {}
    for param in state_dict.keys():
        if param not in model_state_dict:
            debug(f'Parameter is not found: {param}.')
        elif model_state_dict[param].shape != state_dict[param].shape:
            debug(f'Shape of parameter is error: {param}.')
        else:
            load_state_dict[param] = state_dict[param]
            debug(f'Load parameter: {param}.')

    model_state_dict.update(load_state_dict)
    model.load_state_dict(model_state_dict)

    device = torch.device('cuda:2' if torch.cuda.is_available() else 'cpu')
    model = model.to(device)

    return model

def f (expected,precited):
    acc = metrics.accuracy_score(expected, precited)
    # print('--acc:', acc)
    f1 = metrics.f1_score(np.array(expected), np.array(precited), average='micro')
    # print('--f1:', f1)
    mcm = metrics.multilabel_confusion_matrix(expected, precited)
    tn = mcm[:, 0, 0]
    tp = mcm[:, 1, 1]
    fn = mcm[:, 1, 0]
    fp = mcm[:, 0, 1]
    # print('tp: {0}  fn: {1}  fp: {2}'.format(tp, fn, fp))
    return f1,acc,tp,tn

def predict1(model, data, batch_size):
    model.eval()
    pred = []
    data_total = len(data)

    for i in range(0, data_total, batch_size):
        data_now = MoleDataSet(data[i:i + batch_size])
        smile = data_now.smile()

        with torch.no_grad():
            pred_now = model(smile)

        pred_now = pred_now.data.cpu().numpy()

        # if scaler is not None:
        #     ave = scaler[0]
        #     std = scaler[1]
        #     pred_now = np.array(pred_now).astype(float)
        #     change_1 = pred_now * std + ave
        #     pred_now = np.where(np.isnan(change_1), None, change_1)

        pred_now = pred_now.tolist()
        pred.extend(pred_now)

    return pred


class EarlyStopping:
    """Early stops the training if validation loss doesn't improve after a given patience."""
    def __init__(self, patience=7, verbose=False, delta=0):
        """
        Args:
            save_path : 模型保存文件夹
            patience (int): How long to wait after last time validation loss improved.
            当验证集损失在连续7次训练周期中都没有得到降低时，停止模型训练，以防止模型过拟合
                            Default: 7
            verbose (bool): If True, prints a message for each validation loss improvement.
                            Default: False
            delta (float): Minimum change in the monitored quantity to qualify as an improvement.
                            Default: 0
        """
        self.patience = patience
        self.verbose = verbose
        self.counter = 0
        self.best_score = None
        self.early_stop = False
        self.val_loss_min = np.Inf
        self.delta = delta

    def __call__(self, val_loss, model):

        score = -val_loss

        if self.best_score is None:
            self.best_score = score
        elif score < self.best_score + self.delta:
            self.counter += 1
            print(f'EarlyStopping counter: {self.counter} out of {self.patience}')
            if self.counter >= self.patience:
                self.early_stop = True
        else:
            self.best_score = score
            self.counter = 0

def save_model(path,model):
    state = {
            'state_dict':model.state_dict(),
            'data_scaler':None
            }
    torch.save(state,path)

def freeze_model(model, to_freeze_dict, keep_step=None):

    for (name, param) in model.named_parameters():
        if name in to_freeze_dict:
            param.requires_grad = False
        else:
            pass
    return model

if __name__ == '__main__':
    for i in range(1):
        args = set_train_argument()
        train(args)


