import numpy as np
from rdkit import Chem
from rdkit.Chem import AllChem
import pandas as pd
smile_changed = {}
def one_of_k_encoding(x, allowable_set):
    if x not in allowable_set:
        raise Exception("input {0} not in allowable set{1}:".format(
            x, allowable_set))
    return [x == s for s in allowable_set]


def one_of_k_encoding_unk(x, allowable_set):
    """Maps inputs not in the allowable set to the last element."""
    if x not in allowable_set:
        x = allowable_set[-1]
    return [x == s for s in allowable_set]

def bond_features(bond):   #获取原子边
    bond_feats = [0]*25
    bond_feats += one_of_k_encoding(bond.GetBondType(), [Chem.rdchem.BondType.SINGLE,Chem.rdchem.BondType.DOUBLE,
                                                        Chem.rdchem.BondType.TRIPLE,  Chem.rdchem.BondType.AROMATIC])
    bond_feats += [bond.GetIsConjugated()]
    bond_feats += [bond.IsInRing()]
    return np.array(bond_feats,dtype=int)


def get_atom_features(atom):
    atom_type = ['B','C','O','N','F','S','Cl','Br','I','P','other']
    atom_attributes = one_of_k_encoding_unk(atom,atom_type)
    atom_attributes += one_of_k_encoding_unk(len(atom.GetNeighbors()),[0, 1, 2, 3, 4, 5])
    atom_attributes += one_of_k_encoding_unk(atom.GetHybridization(),
                            [Chem.rdchem.HybridizationType.SP, Chem.rdchem.HybridizationType.SP2,
                             Chem.rdchem.HybridizationType.SP3, Chem.rdchem.HybridizationType.SP3D,
                             Chem.rdchem.HybridizationType.SP3D2, 'other'])
    atom_attributes += [atom.GetIsAromatic()]
    atom_attributes += [atom.IsInRing()]
    # atom_attributes += [0,0,0,0,0,0]
    atom_attributes += [0]
    return np.array(atom_attributes, dtype=float)

def featurize_mol(mol):   #最后一位为摩根指纹标识
    node_features = np.array([get_atom_features(atom) for atom in mol.GetAtoms()])
    info = {}
    fp = AllChem.GetMorganFingerprint(mol, 2, bitInfo=info)
    for k in info:  # 取出键，也就是指纹对的标识
        for i in range(len(info[k])):  # 遍历拥有该指纹的子结构
            #         print(info[k][i])
            atmo = info[k][i][0]
            radi = info[k][i][1]
            if radi == 0:
                amap = {}
                radis = radi + 1
                env = Chem.FindAtomEnvironmentOfRadiusN(mol, radis, atmo)
                submol = Chem.PathToSubmol(mol, env, atomMap=amap)
                aaa = list(amap.items())
                for j in aaa:  # 子结构半径为0的加值
                    #                 print(j)
                    if j[0] == atmo:
                        z = j[1]
                        node_features[z][-1] = node_features[z][-1] + 1
                    else:
                        continue
            else:
                amap = {}
                env = Chem.FindAtomEnvironmentOfRadiusN(mol, radi, atmo)
                submol = Chem.PathToSubmol(mol, env, atomMap=amap)
                aaa = list(amap.items())
                for j in aaa:  # 子结构半径不为0的加值
                    #                 print(j)
                    if j[0] == atmo:
                        z = j[1]
                        node_features[z][-1] = node_features[z][-1] + 1
                    else:
                        z = j[1]
                        node_features[z][-1] = node_features[z][-1] + 0.5
    # mol_bond_features = []
    # row, col = [], []
    # for bond in mol.GetBonds():
    #     bond_feats = bond_features(bond)
    #     mol_bond_features.append(bond_feats)
    #     start, end = bond.GetBeginAtomIdx(), bond.GetEndAtomIdx()
    #     node_features[start] = node_features[start] + bond_feats
    #     node_features[end] = node_features[end] + bond_feats
    #     row += [start, end]
    #     col += [end, start]
    #
    # edge_index = torch.LongTensor([row, col])
    # adj_matrix = np.eye(mol.GetNumAtoms())
    #
    # for bond in mol.GetBonds():
    #     begin_atom = bond.GetBeginAtom().GetIdx()
    #     end_atom = bond.GetEndAtom().GetIdx()
    #     adj_matrix[begin_atom, end_atom] = adj_matrix[end_atom, begin_atom] = 1
    return node_features  #np.arrray

def ssort(fea,num):  #按照药效团截断
    fea = fea.tolist()
    fea.sort(key = lambda x:x[-1],reverse = True)
    fea = fea[0:num]
    return fea


if __name__ == '__main__':
    df = pd.read_csv("D:/re/Data/MoleculeNet/bace.csv")
    x= df.SMILES.values
    for smi in x:
        mol = Chem.MolFromSmiles(smi)
        fea = featurize_mol(mol)
    print(type(fea))

